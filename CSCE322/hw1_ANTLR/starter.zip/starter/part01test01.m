{ Moves    @ [   u _   r _   l _   u _   u _   d _   r _   u _   d _   u _   u _   u _   l _   u _   l _   u _   l _   d _   d _   r]     }     
{ Maze    @     (   
  x     x     x     x     x     x     x     x     x     x$    
  x     -     -     -     -     -     -     -     -     x$     
  x     -     -     -     -     -     1     -     -     x$  
  x     -     -     -     -     -     -     -     -     x$    
  x     -     -     -     -     -     -     -     x     x$ 
  x     -     -     -     -     -     -     -     -     x$    
  x     -     -     -     -     x     -     -     -     x$  
  x     -     -     -     -     -     -     x     4     x$  
  x     -     -     -     -     -     2     -     -     x$   
  x     g     -     -     -     -     -     -     -     x$ 
  x     -     -     -     -     -     -     -     -     x$  
  x     -     -     -     -     -     -     -     -     x$    
  x     -     -     -     -     -     -     x     3     x$     
  x     x     x     x     x     x     x     x     x     x  
)
}    
